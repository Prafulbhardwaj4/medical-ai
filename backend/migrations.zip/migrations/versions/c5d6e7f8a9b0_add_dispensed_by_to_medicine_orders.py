"""add dispensed_by to medicine_orders — Schedule H1/X register needs the dispensing pharmacist

Revision ID: c5d6e7f8a9b0
Revises: a3b4c5d6e7f8
Create Date: 2026-07-30 00:00:00
"""
from alembic import op
import sqlalchemy as sa

revision = 'c5d6e7f8a9b0'
down_revision = 'a3b4c5d6e7f8'


def upgrade():
    bind = op.get_bind()
    insp = sa.inspect(bind)
    existing_cols = {c['name'] for c in insp.get_columns('medicine_orders')}
    if 'dispensed_by' not in existing_cols:
        with op.batch_alter_table('medicine_orders') as batch_op:
            batch_op.add_column(sa.Column('dispensed_by', sa.Integer(), sa.ForeignKey('doctors.id'), nullable=True))


def downgrade():
    with op.batch_alter_table('medicine_orders') as batch_op:
        batch_op.drop_column('dispensed_by')