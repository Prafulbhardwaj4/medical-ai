"""add appointment payment_method and paid_at

Revision ID: f4a5b6c7d8e9
Revises: <SET THIS to your current `alembic heads` output — repo has multiple unmerged heads, don't guess>
Create Date: 2026-09-01
"""
from alembic import op
import sqlalchemy as sa

revision = 'f4a5b6c7d8e9'
down_revision = None  # <-- fill in before running
branch_labels = None
depends_on = None


def upgrade():
    op.add_column('appointments', sa.Column('payment_method', sa.String(), nullable=True))
    op.add_column('appointments', sa.Column('paid_at', sa.DateTime(), nullable=True))


def downgrade():
    op.drop_column('appointments', 'paid_at')
    op.drop_column('appointments', 'payment_method')